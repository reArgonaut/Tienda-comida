// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyBtqTRvpm1oxn9L06XPGx05d9feSiipo5E",
    authDomain: "usuarios-dc472.firebaseapp.com",
    databaseURL: "https://usuarios-dc472.firebaseio.com",
    projectId: "usuarios-dc472",
    storageBucket: "usuarios-dc472.appspot.com",
    messagingSenderId: "707235841546",
    appId: "1:707235841546:web:e3e3e3f138709c05c801f3",
    measurementId: "G-K334B38XC0"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

function registrar(){
    var email=  document.getElementById("email").value;
    var password=  document.getElementById("password").value;

    firebase.auth().createUserWithEmailAndPassword(email, password).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...
      });
}


function ingreso(){
    var email2=  document.getElementById("email2").value;
    var password2=  document.getElementById("password2").value;
    
    firebase.auth().signInWithEmailAndPassword(email2, password2).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...
      });

    if(email2=="adrianyoop@gmail.com" && password2=="adrian"){
        window.location.href = 'admin.php';
    }else{
        window.location.href = 'index.php';
    }
}

function salir(){
    firebase.auth().signOut().then(function() {
        // Sign-out successful.
        window.location.href = 'login.php';
      }).catch(function(error) {
        // An error happened.
        print("Error insesperado");
      });
}