<?php
    include('conexion.php');
    $id=$_GET['codigoComida'];
    $form=$_GET['form'];

        $sql="DELETE FROM comidas Where codigoComida={$id}";
    

    if($conexion->query($sql)){

        header('Location:productos.php');
    }else{
        echo "Fallo: ".$sql."--".$conexion->error;
    }
    $conexion->close();


?>