<?php 
    session_start(); 
    require("conexion.php"); 
    if(isset($_GET['pagina'])){      
        $paginas=array("comida", "carrito");      
        if(in_array($_GET['pagina'], $paginas)) {         
            $_pagina=$_GET['pagina'];           
        }else{            
            $_pagina="comida";             
        }          
    }else{         
        $_pagina="comida";  
    } 


?>
<!DOCTYPE html>
<html lang="es">
<meta charset="UTF-8">

<head class="image">
    <link rel="stylesheet" href="style.css" />
    <title>Carrito de comidas</title>
    <button onclick="salir()"> Cerrar Sesion</button>
</head>

<body background="Goron_shop.jpg">
    <div id="container">
        <div id="main">
            <?php require($_pagina.".php"); ?>
        </div>
    </div>
    <script>
    var audio = new Audio('Daft_Punk_- Lose Your self to Dance.mp3');
    audio.play();
    </script>
    <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/6.2.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
    <script src="app.js"></script>
</body>

</html>