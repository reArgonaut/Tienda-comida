<?php 
  
  $server="localhost"; 
  $user="root"; 
  $pass=""; 
  $db="db_comida"; 
    
  // connect to mysql 
    
  $conexion = mysqli_connect($server, $user, $pass, $db) or die("Lo siento, no se puede conectar al servidor."); 
    
  // select the db 
    
  //mysqli_select_db($conexion, $db) or die("Lo siento, no se puede conectar  a la base de datos."); 

?>