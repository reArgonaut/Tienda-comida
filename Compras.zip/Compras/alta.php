<?php
    include('conexion.php');
    if( isset($_POST['submitP']) ){ //Se presiono el submit (se detecta el click)
        
        $nombre = $_POST['nombreComida'];
        $descripcion = $_POST['descripcionComida'];
        $precio = $_POST['precioComida'];

            $sql = "INSERT INTO comidas (nombreComida, descripcionComida, precioComida, codigoTipoComida) VALUES ('{$nombre}','{$descripcion}','{$precio}',9)";
            
            if($conexion -> connect_errno){
                printf("Fallo la conexion", $conexion->connect_error);
            }
            if($conexion -> query($sql)){
             //   echo "Se insertaron los datos";
                header("location:productos.php");
            }else{
                echo "Hubo un error".$conexion->error;
            }
    
        }
    


$conexion->close();