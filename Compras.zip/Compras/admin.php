<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Menu</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-app.js"></script>
     <script src="https://www.gstatic.com/firebasejs/6.2.0/firebase-auth.js"></script>
     <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
     <script src="app.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style3.css">
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="admin.php">TIENDISLOQUIS</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="productos.php">Productos</a></li>
      <button onclick="salir()"> Cerrar Sesion</button>

    </ul>
  </div>
</nav>

  
<div class="container alv">
  <h3>Productos</h3>
        <form action="alta.php" class="form-group" method="POST">
            <div class="form-group">
                <label for="nombreComida">Nombre</label>
                <input class="form-control" type="text" name="nombreComida" id="nombreComida">
            </div>
            <div class="form-group">
                <label for="descripcionComida">Descripcion</label>
                <input class="form-control" type="text" name="descripcionComida" id="descripcionComida">
            </div>
            <div class="form-group">
                <label for="precioComida">Precio</label>
                <input class="form-control" type="text" name="precioComida" id="precioComida">
            </div>
            <input style="color:black;" type="submit" name="submitP" value="Enviar">
        </form>
    </div>
    <script>
    var audio = new Audio('Daft_Punk_- Lose Your self to Dance.mp3');
    audio.play();
    </script>
</body>
</html>
