<?php

    include('conexion.php');
    $sql = "SELECT * FROM comidas";

    if($conexion -> connect_errno){
        printf("Fallo la conexion", $conexion->connect_error);
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Menu</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-app.js"></script>
     <script src="https://www.gstatic.com/firebasejs/6.2.0/firebase-auth.js"></script>
     <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
     <script src="app.js"></script> 
  <link rel="stylesheet" href="css/style3.css">
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="admin.php">TIENDISLOQUIS</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="productos.php">Productos</a></li>
      <button onclick="salir()"> Cerrar Sesion</button>
    </ul>
  </div>
</nav>
  
<div class="container alv">
    <table class='table alv'>
        <th>
            <td>Id</td>
            <td>Nombre</td>
            <td>Descripcion</td>
            <td>Precio</td>
        </th>
    <?php
    if($res = $conexion -> query($sql)){
        if($res -> num_rows > 0){
            while($fila = $res -> fetch_assoc()){
    ?>
        <tr>
            <?php
                echo "<td colspan='2'>{$fila['codigoComida']}</td>";
                echo "<td>{$fila['nombreComida']}</td>";
                echo "<td>{$fila['descripcionComida']}</td>";
                echo "<td>{$fila['precioComida']}</td>";
                echo "<td><a href='delete.php?id={$fila['codigoComida']}&form=prod'>Eliminar</a></td>";
                }
            }
        }
    }
            ?>
        </tr>
    </table>
</body>
</html>