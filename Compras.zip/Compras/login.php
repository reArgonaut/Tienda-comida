<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style2.css" />
    <title>INICIO</title>
    <h1>INICIO DE SESION</h1>
    
</head>
    <body>

<div class="imgcontainer">
    <img src="images.jpg" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Correo</b></label>
    <input id="email2" type="text" placeholder="Ingresa email..." name="uname" required>
    <label for="psw"><b>Contraseña</b></label>
    <input id="password2" type="password" placeholder="Ingresa contraseña..." name="psw" required>
    <span class="psw">No tienes <a href="registro.php">cuenta?</a></span>
    <button onclick="ingreso()" >Acceder</button>
    </form>
    
  </div>
     <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-app.js"></script>
     <script src="https://www.gstatic.com/firebasejs/6.2.0/firebase-auth.js"></script>
     <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
     <script src="app.js"></script>  
  </div>
    </body>
</html>
